import RPi.GPIO as GPIO

# Declare the pin number
PS = 0  #Phase
PW = 0  #Power

P_or_S = 26

OPT = 19
D0 = 22
D1 = 10
D2 = 9
D3 = 11
D4 = 0
D5 = 5
D6 = 6
D7 = 13
pins_P = [D0, D1, D2, D3, D4, D5, D6, D7]

# PE43711
PIN_HIGH_A = 0
A0 = 14
A1 = 15
A2 = 18
A3 = 23
A4 = 24
A5 = 25
A6 = 8
LE = 7
pins_A = [A0, A1, A2, A3, A4, A5, A6]

